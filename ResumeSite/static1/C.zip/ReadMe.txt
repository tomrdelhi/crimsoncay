Originally created as an exercise for my third year operating systems course, this C program factors a number into two primes if possible. It does this recursively, using a sieve of Eratosthenes to find primes to check, giving each instance of the function its own thread and piping the results back and forth. This ZIP includes:

pfact.c - The C source file

pfact - A compiled pfact.c

Makefile - Run this makefile to compile pfact.c into pfact.o and the runnable pfact.