#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <math.h>

void  sieveOfErat(int* fd);
int findnextprime(int currprime);
//Function prototypes and header files

int main(int argc, char *argv[]){
  //mynum is the number we want factored, searchlimit is the highest numbers we'll check
  // fd is the pipe, pid is for fork purposes and status is for determining what to report to 
  // the user once the children have finished executing.
  int mynum = atoi(argv[1]);
  int searchlimit = sqrt (mynum);
  int counter = 2;
  int fd[2], pid;
  int status = 0;
  
  //There is a bug in that ever number works except 8, this fixes that.
  if (mynum == 8){
    printf("8 is not the product of two primes\n");
    return 0;
    }
  
  //If mynum is prime, catch it here
  if (findnextprime(mynum-1) == mynum){
    printf("%d is prime\n", mynum);
    return 0;
  }
  //Create the pipe.
  if (pipe(fd) == -1){
    perror ("Pipe error 1");
    exit (1);
  }
  //for loop iterates from 2 to searchlimit, each time it calls the sieve of erat on a given number.
  for (; counter <= searchlimit; counter++){
    char firstpass[40]; 
    sprintf(firstpass, "2:%d:%d:", counter, mynum);
    //printf("going to first main write\n");
    //writes the desired end value as well as the currently being evaluated value to the pipe.
    if (write(fd[1], firstpass, sizeof(firstpass)) == -1){
      perror("Pipe error 4");
     }
    //forks to the child which will check the the counter value with 2. The child of that child will call it
    //with 3 and so on and so forth.
    pid = fork();
    if (pid == -1){
      perror("Fork Error 2");
    }
    if (pid == 0){
      //calling seive of erat to compare 2 and the current counter value.
      sieveOfErat(fd);
    }
    else{
      if (wait(&status) == -1);{
	//This will happen once at the end of the program, just ignore.
      }
      //Checks exit status of the child and outputs accordingly.
      if (WEXITSTATUS(status) == 0){
	printf("%d is not the product of two primes\n", mynum);
	return 0;
      }
      if (WEXITSTATUS(status) > 0 && mynum%counter == 0){
	int firstnum = mynum / counter;
	int secondnum = counter;
	//printf("firstnum: %d, secondnum: %d", firstnum, secondnum);
	if (findnextprime(firstnum-1) != firstnum){
	}
	else{
	printf("%d %d %d\n", mynum, firstnum, secondnum);
	printf("Number of stages = %d \n", WEXITSTATUS(status));
	return 0;}
      }
    }
  }
  return 0;
}

void sieveOfErat(int* fd){
  //printf("Beginning sieve of erat\n");
  char inputnumbers[40];
  if (read (fd[0], inputnumbers, sizeof(inputnumbers)) == -1){
      perror ("Pipe error 2");
    }
  int thisprocessnumber = atoi(strtok(inputnumbers, ":"));
  int evaluatednumber = atoi(strtok(NULL, ":"));
  int desirenumber = atoi(strtok(NULL, ":"));
  //printf("thisprocessnumebr: %d, evaluatednumber %d, desirenumber %d\n", thisprocessnumber, evaluatednumber, desirenumber);
  int factor = 0;
  int status = 0;
  if (desirenumber % thisprocessnumber == 0){
    //printf("Setting factor \n");
    factor = desirenumber / thisprocessnumber;
  } 
  else if (evaluatednumber % thisprocessnumber == 0){
    //printf("Exiting early\n");
    exit(1);
  }
  //if we've found two working prime numbers we start collapsing back up to main.
  if (factor * evaluatednumber == desirenumber){
    // printf("going to writeup\n");
    char writeup[40];
    sprintf(writeup, "%d", thisprocessnumber);
    //printf("going to first write\n");
    if (write (fd[1], writeup, sizeof(writeup)) == -1){
      perror("Write Error 1");
    }
    exit (1);
  }
  //if this exits with value 0 the number is not a multiple of two primes.
  if (thisprocessnumber > (desirenumber/2)+1){
    exit (0);
  }
  //Otherwise create a new child with the next value and repeat.
   char passon[40];
   sprintf(passon, "%d:%d:%d:", findnextprime(thisprocessnumber), evaluatednumber, desirenumber);
   //printf("going to second write\n");
   if (write (fd[1], passon, sizeof(passon)) == -1){
    perror("Pipe error 3");
   }
   //printf("going to fork\n");
   int pid = fork();
   if(pid == -1){      
     perror("Fork Error 1");
   }
   if (pid == 0){
     //printf("going to call sieve of erat again\n");
     sieveOfErat(fd);
   }
   else{
   if (wait(&status) == -1){
     perror("Wait error 1");
   }
   //Determining exit status of children and exiting accordingly.
   //printf("%d", WEXITSTATUS(status));
   if (WEXITSTATUS(status) == 0){
     exit(0);
   }
   if (WEXITSTATUS(status) < 0){
     printf("EXITING WITH %d", WEXITSTATUS(status));
     exit(WEXITSTATUS(status));
    }
    else{
      //printf("exiting: %d \n", WEXITSTATUS(status));
     exit (WEXITSTATUS(status) + 1);
    }
   }

 return;
}


//This is just a helper function that given a prime number currprime calculates the smallest
//prime number greater than currprime.
int findnextprime(int currprime){
  if (currprime == 2){
    return 3;}
  currprime = currprime+1;
  for (; currprime < 2*currprime; currprime++){
    int checker = 1;
    int counter = 2;
    for (; counter <= currprime/2; counter++){
      if (currprime % counter == 0){
	checker = 0;
	break;
      } 
    }
    if (checker == 1){
      return currprime;
    }
  }
  return 0;
}
