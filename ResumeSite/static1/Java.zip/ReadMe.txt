This desktop applet was built during the summer as a way to practice my Java. Designed because my friends and I couldn't afford a supplemental product for the collectable card game Magic: The Gathering, the applet cycles through a deck of cards that act as environmental modifiers for the card game, allowing you to reveal additional ones to accommodate the effects of certain cards and returning used cards to the bottom of the deck as the game mechanics demand. This zip file includes:

MainMenu.java and PlanechaseGuiEdition.java - Source files for the applet.

PlaneswalkerRunnable.jar - Runnable jar file of the applet.