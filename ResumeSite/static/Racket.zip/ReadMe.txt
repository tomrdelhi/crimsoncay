This was the first assignment for the third year functional programming course I completed. It is a simple interpreter for a programming language based off Shakespeare, where characters represent variables and a sequence of pre-defined "reserved words" represented various arithmetic operations. When evaluated on a "script" the program produces a list of integers that are the result. Comments have been left in the code to make obvious which parts where me and which were provided. In this ZIP:

Shakespear.rkt - The source code for the racket program, has the included smaple.txt hardcoded into it to run.

sample.txt - An example script, evaluates to (6, -3, 15, 18, 7, 18, -40, 8)
