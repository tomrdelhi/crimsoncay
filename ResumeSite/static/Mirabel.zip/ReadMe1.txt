As part of the University of Toronto Arts and Sciences Entrepreneurship program I created, along with another programmer and a subject matter expert, a web application designed to recommend shades of foundation based on a selfie. I was in charge of the website front-end which you'll find here. This is spread across the following files:

index.html - The main landing page for the application, the user can check their hardware, and take and submit photos. 

Answers.html - The results page for the applet. Since the zip contains only the front end of the site the answers page simply selects from a small group of cosmetics and colours at random.

MUPlaceholder.jpg - A stock cosmetic image for the results page in Answers.html

Tinter.css - Stylings for index and answers.html.

TintPhotMan.js - JavaScript functions mostly concerned with displaying the video feed, and taking and displaying images the user takes.